clear all
load('DirectMarketing.mat')

rng(10000)

X_train = X;
y_train = y;
X_validation = [X_validation;X_test];
y_validation = [y_validation;y_test];

batchsize = 100;
n_units = [20];


% run AIFVB
tic
eps0 = .001;
[W_seq,beta,mean_sigma2,shrinkage_gamma_seq,MSE_AIFVB_val_best,MSE_AIFVB] = DL_training_AIFVB(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_AIFVB_test,MSE_AIFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_AIFVB = toc;

% run IFVB
tic
eps0 = .001;
[W_seq,beta,mean_sigma2,shrinkage_gamma_seq,MSE_IFVB_val_best,MSE_IFVB] = DL_training_IFVB(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_IFVB_test,MSE_IFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_IFVB = toc;

% run NAGVAC
tic
eps0 = .01;
[W_seq,beta,mean_sigma2,shrinkage_gamma_seq,MSE_NAGVAG_val_best,MSE_NAGVAG] = DL_training(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_NAGVAG_test,MSE_NAGVAG_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_NAGVAG = toc;

% train with ADAM
tic
eps0 = .001;
[W_seq,beta,mean_sigma2,shrinkage_gamma_seq,MSE_ADAM_val_best,MSE_ADAM] = DL_training_Adam(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_ADAM_test,MSE_ADAM_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_ADAM = toc;


plot(MSE_NAGVAG,'--b','LineWidth',1.5)
hold on
plot(MSE_IFVB,'-r','LineWidth',1.5)
hold on
plot(MSE_AIFVB,'-.c','LineWidth',1.5)
hold on
plot(MSE_ADAM,':k','LineWidth',1.5)
hold off 
legend('NAGVAG','IFVB','AIFVB','ADAM')
xlabel('Iteration',FontSize=14)
ylabel('Validation MSE',FontSize=14)
MSE_AIFVB_val_best
MSE_IFVB_val_best
MSE_NAGVAG_val_best
MSE_ADAM_val_best