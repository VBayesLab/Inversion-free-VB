Implementing the Inverse-free Natural Gradient VB method Bayesian neural net regression
See Example 4 in "Natural Gradient Variational Bayes without Fisher Matrix Analytic Calculation and Its Inversion" by GODICHON-BAGGIONI, D. NGUYEN, AND M-N. TRAN.

DirectMarketing.m runs and compares the four methods: IFVB, AIFVB, NAGVAC and ADAM

