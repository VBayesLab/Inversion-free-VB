clear all
n = 200;
y = 57;
initial_lambda = [5;45];
alpha_star = y+1; beta_star = n-y+1; % true values
lambda_star = [alpha_star;beta_star];

%------------------------- IFVB -------------------------------%
lambda = initial_lambda;
d_lambda = 2;
alpha_stepsize = 0.8; % use in the step size
niter = 100000;iter = 1;
outer_product = [];
stop = false;
MSE_IFVB = 0;
while ~stop    
    lambda_old = lambda;
    stepsize = 10/(1+iter)^alpha_stepsize;
    
    alpha = lambda(1); beta = lambda(2);
    aux = psi(1,alpha+beta);    
    % Euclidean gradient of lower bound
    Grad_LB = [(alpha_star-alpha)*(psi(1,alpha)-aux)-(beta_star-beta)*aux;
               (beta_star-beta)*(psi(1,beta)-aux)-(alpha_star-alpha)*aux];
    % update outer product
    theta = betarnd(alpha,beta);    
    grad_log_q_lambda = [psi(alpha+beta)-psi(alpha)+log(theta);
                        psi(alpha+beta)-psi(beta)+log(1-theta)];
    outer_product_new = grad_log_q_lambda;
    NatGradient = Grad_LB;
    scale = grad_log_q_lambda'*grad_log_q_lambda;
    for k = 1:size(outer_product,2)
        NatGradient = NatGradient - (outer_product(:,k)'*Grad_LB)*outer_product(:,k);
        outer_product_new = outer_product_new - (outer_product(:,k)'*grad_log_q_lambda)*outer_product(:,k);
        scale = scale - (outer_product(:,k)'*grad_log_q_lambda)^2;
    end
    outer_product_new = 1/sqrt(1+scale)*outer_product_new;
    outer_product =[outer_product,outer_product_new];
    if size(outer_product,2)>100
        outer_product = outer_product(:,end-99:end);
    end
    NatGradient = iter*NatGradient;
    lambda = lambda+stepsize*NatGradient;    
    lambda(lambda<=0) = 0.01;   
    
    MSE_IFVB(iter) = norm(lambda-lambda_star);
    
    iter = iter+1
    if (mean(abs(lambda-lambda_old))<=0.0001)||iter>niter stop = true; end
end
lambda_IFVB = lambda
lambda_star

x = 0:.01:.6;
yy_exact = betapdf(x,y+1,n-y+1);
yy_IFVB = betapdf(x,lambda_IFVB(1),lambda_IFVB(2));
plot(x,yy_exact,'k-',x,yy_IFVB,'g-d','LineWidth',2);
h_legend = legend('True','IFVB'); 
set(h_legend,'FontSize',15)
