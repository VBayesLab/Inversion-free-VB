clear all
subplot(1,2,1)
load("results1.mat")
x = 0:.01:.6;
yy_exact = betapdf(x,y+1,n-y+1);
yy_VB = betapdf(x,lambda1(1),lambda1(2));
yy_NGVB = betapdf(x,lambda_NGVB(1),lambda_NGVB(2));
yy_IFVB = betapdf(x,lambda_IFVB(1),lambda_IFVB(2));
plot(x,yy_exact,'k-',x,yy_VB,'r-x',x,yy_NGVB,'b-o',x,yy_IFVB,'g-d','LineWidth',2);
h_legend = legend('True','Euclidean gradient','NGVB','IFVB'); 
set(h_legend,'FontSize',15)

subplot(1,2,2)
load("results2.mat")
x = 0:.01:.6;
yy_exact = betapdf(x,y+1,n-y+1);
yy_VB = betapdf(x,lambda1(1),lambda1(2));
yy_NGVB = betapdf(x,lambda_NGVB(1),lambda_NGVB(2));
yy_IFVB = betapdf(x,lambda_IFVB(1),lambda_IFVB(2));
plot(x,yy_exact,'k-',x,yy_VB,'r-x',x,yy_NGVB,'b-o',x,yy_IFVB,'g-d','LineWidth',2);
h_legend = legend('True','Euclidean gradient','NGVB','IFVB'); 
set(h_legend,'FontSize',15)


figure(1)
load("results2.mat")
fontsize = 18;
plot(MSE_AIFVB,'-','LineWidth',3);
hold on
plot(MSE_IFVB,'--','LineWidth',3);
hold on
plot(MSE_NGVB,'-.','LineWidth',3);
hold off
legend('AIFVB','IFVB','NGVB','FontSize',fontsize)
xlabel('Iteration','FontSize',fontsize);
ylabel('MSE','FontSize',fontsize);

