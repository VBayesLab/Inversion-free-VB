% Implement Inversion-free VB methods with control variate 
% for the normal model example

clear all
rng('default');

n = 10;
y = [11; 12; 8; 10; 9; 8; 9; 10; 13; 7]; %data
%===========================

% ============== run exact natural grad VB (NGVB) ==================%
d = 4;
S = 1000;
momentum_weight = 0.9;
eps0 = 0.001; 
max_iter = 10000;
patience_max = 200;
tau_threshold = max_iter/2;
t_w = 100;

% hyperparameter
alpha_hp = 1; beta_hp = 1; mu_hp = 0; sigma2_hp = 100; 

lambda = [mean(y);.5;1;1]; % initial lambda
lambda_best = lambda;


mu_mu = lambda(1); sigma2_mu = lambda(2); alpha_sigma2 = lambda(3); beta_sigma2 = lambda(4);
h_lambda = zeros(S,1); % function h_lambda
grad_log_q_lambda = zeros(S,d);
grad_log_q_times_h = zeros(S,d);
parfor s = 1:S    
    % generate theta_s
    mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
    sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);
    
    grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
        log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
    h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);      
    grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
end
cv = zeros(1,d); % control variate 
for i = 1:d
    aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
    cv(i) = aa(1,2)/aa(2,2);
end
grad_LB = mean(grad_log_q_times_h)';
I_igam = [psi(1,alpha_sigma2) -1/beta_sigma2;-1/beta_sigma2 alpha_sigma2/beta_sigma2^2]; % inverse Fisher matrix
grad_LB_nat = [sigma2_mu*grad_LB(1);2*sigma2_mu^2*grad_LB(2);I_igam\grad_LB(3:4)];
grad_LB_bar = grad_LB_nat;

iter = 1;
stop = false;
LB = 0; LB_bar = 0; patience = 0;
Grad_LB_stor=zeros(d,max_iter);
while ~stop    
    
    mu_mu = lambda(1); sigma2_mu = lambda(2); alpha_sigma2 = lambda(3); beta_sigma2 = lambda(4);
    h_lambda = zeros(S,1); % function h_lambda
    grad_log_q_lambda = zeros(S,d);
    grad_log_q_times_h = zeros(S,d);
    grad_log_q_times_h_cv = zeros(S,d);
    parfor s = 1:S    
        % generate theta_s
        mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
        sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);

        grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
            log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
        h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);    
        grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
        grad_log_q_times_h_cv(s,:) = grad_log_q_lambda(s,:).*(h_lambda(s)-cv);
    end
    cv = zeros(1,d); % control variate 
    for i = 1:d
        aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
        cv(i) = aa(1,2)/aa(2,2);
    end
    grad_LB = mean(grad_log_q_times_h_cv)';
    Grad_LB_stor(:,iter)=grad_LB;
 
    I_igam = [psi(1,alpha_sigma2) -1/beta_sigma2;-1/beta_sigma2 alpha_sigma2/beta_sigma2^2];
    grad_LB_nat = [sigma2_mu*grad_LB(1);2*sigma2_mu^2*grad_LB(2);I_igam\grad_LB(3:4)];

    grad_LB_bar = momentum_weight*grad_LB_bar+(1-momentum_weight)*grad_LB_nat;

    if iter>=tau_threshold
       stepsize = eps0*tau_threshold/iter;
    else
       stepsize = eps0;
    end
    lambda = lambda+stepsize*grad_LB_bar; %update lambda
    
    LB(iter) = mean(h_lambda);
    
    if iter>=t_w
        LB_bar(iter-t_w+1) = mean(LB(iter-t_w+1:iter));
        LB_bar_current = LB_bar(iter-t_w+1)
    end
       
    if iter>t_w
        if (LB_bar(iter-t_w+1)>=max(LB_bar))
            lambda_best = lambda;
            patience = 0;
        else
            patience = patience+1;
        end
    end
    
    if (patience>patience_max)||(iter>max_iter) stop = true; end 
        
    iter = iter+1
 
end
lambda = lambda_best;
NGlambda = lambda_best';
mu_mu = lambda(1); sigma2_mu = lambda(2); alpha_sigma2 = lambda(3); beta_sigma2 = lambda(4);

%%%%%%%%%%%%%%%%%%%%%%%%% run Gibbs samppling %%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
n = length(y);
Nburn = 10000;
Niter = 20000;
N = Nburn + Niter; % number of MCMC iterations
mu_mcmc = zeros(N,1); % to store MCMC chain for mu
sigma2_mcmc = zeros(N,1); % to store MCMC chain for sigma2
y_bar = mean(y);
i = 1;
mu_mcmc(1) = y_bar; sigma2_mcmc(1) = var(y); %initial value
while i<N
    scale = 1/(1/sigma2_hp+n/sigma2_mcmc(i));
    location = (mu_hp/sigma2_hp+n*y_bar/sigma2_mcmc(i))*scale;
    mu_mcmc(i+1) = normrnd(location,sqrt(scale));
    aux = gamrnd(n/2+alpha_hp,1/(beta_hp+sum((y-mu_mcmc(i+1)).^2)/2));
    sigma2_mcmc(i+1) = 1/aux;
    i = i+1;
end
CPU_MCMC = toc % CPU time taken to run the Gibbs sampling 
mu_mcmc = mu_mcmc(Nburn+1:N); % remove burn-in
sigma2_mcmc = sigma2_mcmc(Nburn+1:N); % remove burn-in
[mean(mu_mcmc), std(mu_mcmc),mean(sigma2_mcmc),std(sigma2_mcmc)]


%=============================================================================
%================ Inversion free VB ==========================================

stop = false;
IFLB = 0; IFLB_bar = 0; patience = 0;
lambda = [mean(y);.5;1;1]; % initial lambda
lambda_best=lambda;
IFlambda=lambda_best;
S=1000;

max_iter = 20000;
iter = 1;
patience_max = 200;

alphapower=0.6;
c_beta=.01;
betapower=alphapower-1/2-0.001;

mu0Z=zeros(d,1);
Sigma0Z=eye(d,d);

IFmatrix=10^(-4)*eye(d,d);

%control variate
h_lambda = zeros(S,1); % function h_lambda
grad_log_q_lambda = zeros(S,d);
grad_log_q_times_h = zeros(S,d);
parfor s = 1:S    
    % generate theta_s
    mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
    sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);
    
    grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
        log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
    h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);      
    grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
end
cv = zeros(1,d); % control variate 
for i = 1:d
    aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
    cv(i) = aa(1,2)/aa(2,2);
end
grad_LB = mean(grad_log_q_times_h)';

while ~stop    
    IFlambda=real(IFlambda); % get the real part of IFlambda just in case for now
    IFlambda(IFlambda<=0)=0.001;
    mu_mu = IFlambda(1); sigma2_mu = IFlambda(2); alpha_sigma2 = IFlambda(3); beta_sigma2 = IFlambda(4);
    h_lambda = zeros(S,1); % function h_lambda
    grad_log_q_lambda = zeros(S,d);
    grad_log_q_times_h = zeros(S,d);
    
    %estimate the gradient using batch size S
     parfor s = 1:S    
        % generate theta_s
        mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
        sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);

        grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
            log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
        h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);    
        grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
        grad_log_q_times_h_cv(s,:) = grad_log_q_lambda(s,:).*(h_lambda(s)-cv);    
    end
    cv = zeros(1,d); % control variate 
    for i = 1:d
        aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
        cv(i) = aa(1,2)/aa(2,2);
    end
    grad_LB = mean(grad_log_q_times_h_cv)';
    
    % %estimate the Fisher information matrix
    S_IF = 10;
    for s = 1:S_IF
        mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
        sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);
        gradq_lambda =[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
            log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2];
        IFmatrix=IFmatrix-1./(1+gradq_lambda'*IFmatrix*gradq_lambda)*IFmatrix*(gradq_lambda*gradq_lambda')*IFmatrix;
        Z=mvnrnd(mu0Z,Sigma0Z,1)';
        IFmatrix=IFmatrix-c_beta*(iter+1)^(-betapower)/(1+c_beta*(iter+1)^(-betapower)*Z'*IFmatrix*Z)*IFmatrix*(Z*Z')*IFmatrix;
    end
    stepsize=10/(1+iter)^alphapower;
      
    IFlambda = IFlambda+stepsize*S_IF*(iter+1)*IFmatrix*grad_LB; %update lambda
      
      IFLB(iter) = mean(h_lambda);
        if iter>=t_w
           IFLB_bar(iter-t_w+1) = mean(IFLB(iter-t_w+1:iter));
           IFLB_bar_current = IFLB_bar(iter-t_w+1)
       end
       
        if iter>t_w
            if (IFLB_bar(iter-t_w+1)>=max(IFLB_bar))
                lambda_best = IFlambda;
                patience = 0;
            else
                patience = patience+1;
            end
        end
       
       if (patience>patience_max)||(iter>max_iter) stop = true; end 
 
     iter = iter+1
  end

IFlambda = lambda_best;
IFlambda=real(IFlambda)' % get the real part of IFlambda just in case
IFmu_mu = IFlambda(1); IFsigma2_mu = IFlambda(2); IFalpha_sigma2 = IFlambda(3); IFbeta_sigma2 = IFlambda(4);

%Keep track the paramters from Natural garident descent
mu_mu = NGlambda(1); sigma2_mu = NGlambda(2); alpha_sigma2 = NGlambda(3); beta_sigma2 = NGlambda(4);

%=========================================================================
%===================== Averaged Inversion free VB ========================

stop = false;
AIFLB = 0; AIFLB_bar = 0; patience = 0;
lambda = [mean(y);.5;1;1]; % initial lambda
lambda_best=lambda;
IFlambda=lambda_best;
AIFlambda=IFlambda; %average lmabda

S=1000;

max_iter = 20000;
iter = 1;
tau_threshold = max_iter;
patience_max = 200;
t_w = 100;

alphapower=0.6;
c_beta=.001;
betapower=alphapower-1/2-0.001;
wpower=2;

mu0Z=zeros(d,1);
Sigma0Z=eye(d,d);

IFmatrix=10^(-4)*eye(d,d);

%control variate
h_lambda = zeros(S,1); % function h_lambda
grad_log_q_lambda = zeros(S,d);
grad_log_q_times_h = zeros(S,d);
parfor s = 1:S    
    % generate theta_s
    mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
    sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);
    
    grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
        log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
    h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);      
    grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
end
cv = zeros(1,d); % control variate 
for i = 1:d
    aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
    cv(i) = aa(1,2)/aa(2,2);
end

while ~stop    
    IFlambda=real(IFlambda); % get the real part of IFlambda just in case for now
    AIFlambda=real(AIFlambda); % get the real part of IFlambda just in case for now
    IFlambda(IFlambda<=0)=0.001;
    AIFlambda(IFlambda<=0)=0.001;
    
    mu_mu = IFlambda(1); sigma2_mu = IFlambda(2); alpha_sigma2 = IFlambda(3); beta_sigma2 = IFlambda(4);
    mu_mubar = AIFlambda(1); sigma2_mubar = AIFlambda(2); alpha_sigma2bar = AIFlambda(3); beta_sigma2bar = AIFlambda(4);
    
    h_lambda = zeros(S,1); % function h_lambda
    h_lambdabar = zeros(S,1); % function h_lambda

    grad_log_q_lambda = zeros(S,d);
    grad_log_q_times_h = zeros(S,d);
    
   
   %IFmatrix=10^(0)/2*eye(d,d);
   
    %estimate the gradient using batch size S
    parfor s = 1:S    
        % generate theta_s
        mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
        sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);

        mubar = normrnd(mu_mubar,sqrt(sigma2_mubar),1);
        sigma2bar = 1./gamrnd(alpha_sigma2bar,1/beta_sigma2bar,1);

        grad_log_q_lambda(s,:)=[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
            log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2]';
        
        h_lambda(s) = h_lambda_fun(y,mu,sigma2,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mu,sigma2_mu,alpha_sigma2,beta_sigma2);    
        
        %compute h_lambdabar to estimate the ELBO later
        h_lambdabar(s) = h_lambda_fun(y,mubar,sigma2bar,alpha_hp,beta_hp,mu_hp,sigma2_hp,mu_mubar,sigma2_mubar,alpha_sigma2bar,beta_sigma2bar);    
        
        grad_log_q_times_h(s,:) = grad_log_q_lambda(s,:)*h_lambda(s);
        grad_log_q_times_h_cv(s,:) = grad_log_q_lambda(s,:).*(h_lambda(s)-cv);  
    end
    cv = zeros(1,d); % control variate 
    for i = 1:d
        aa = cov(grad_log_q_times_h(:,i),grad_log_q_lambda(:,i));
        cv(i) = aa(1,2)/aa(2,2);
    end
    grad_LB = mean(grad_log_q_times_h_cv)';
    
     
%   %generate new samples from AIFlambda to estimate the inverse of Fisher matrix
    S_IF = 20;
    for s = 1:S_IF
        mubar1 = normrnd(mu_mubar,sqrt(sigma2_mubar),1);
        sigma2bar1 = 1./gamrnd(alpha_sigma2bar,1/beta_sigma2bar,1);
        
        grad_log_q_lambdabar=[(mubar1-mu_mubar)/sigma2_mubar;-1/2/sigma2_mubar+(mubar1-mu_mubar)^2/2/sigma2_mubar^2;...
                log(beta_sigma2bar)-psi(alpha_sigma2bar)-log(sigma2bar1);alpha_sigma2bar/beta_sigma2bar-1/sigma2bar1]';

        gradq_lambda=grad_log_q_lambdabar';
        IFmatrix=IFmatrix-1./(1+gradq_lambda'*IFmatrix*gradq_lambda)*IFmatrix*(gradq_lambda*gradq_lambda')*IFmatrix;
        Z=mvnrnd(mu0Z,Sigma0Z,1)';
        IFmatrix=IFmatrix-c_beta*(iter+1)^(-betapower)/(1+c_beta*(iter+1)^(-betapower)*Z'*IFmatrix*Z)*IFmatrix*(Z*Z')*IFmatrix;
    end
    % %generate new samples from IFlambda to estimate the inverse of Fisher matrix
%     for s = 1:S_IF
%         mu = normrnd(mu_mu,sqrt(sigma2_mu),1);
%         sigma2 = 1./gamrnd(alpha_sigma2,1/beta_sigma2,1);
%         gradq_lambda =[(mu-mu_mu)/sigma2_mu;-1/2/sigma2_mu+(mu-mu_mu)^2/2/sigma2_mu^2;...
%             log(beta_sigma2)-psi(alpha_sigma2)-log(sigma2);alpha_sigma2/beta_sigma2-1/sigma2];
%         IFmatrix=IFmatrix-1./(1+gradq_lambda'*IFmatrix*gradq_lambda)*IFmatrix*(gradq_lambda*gradq_lambda')*IFmatrix;
%         Z=mvnrnd(mu0Z,Sigma0Z,1)';
%         IFmatrix=IFmatrix-c_beta*(iter+1)^(-betapower)/(1+c_beta*(iter+1)^(-betapower)*Z'*IFmatrix*Z)*IFmatrix*(Z*Z')*IFmatrix;
%     end

    stepsize=10/(1+iter)^alphapower;
      
    IFlambda = IFlambda+stepsize*S_IF*(iter+1)*IFmatrix*grad_LB; %update lambda
    AIFlambda = AIFlambda +(log(iter+1).^wpower/sum((log((0:iter)+1)).^wpower))*(IFlambda-AIFlambda); %Inv Free: averaging
     
    AIFLB(iter) = mean(h_lambdabar);
      
    if iter>=t_w
       AIFLB_bar(iter-t_w+1) = mean(AIFLB(iter-t_w+1:iter));
       AIFLB_bar_current = AIFLB_bar(iter-t_w+1)
    end
    if iter>t_w
        if (AIFLB_bar(iter-t_w+1)>=max(AIFLB_bar))
            lambda_best = AIFlambda;
            patience = 0;
        else
            patience = patience+1;
        end
    end

    if (patience>patience_max)||(iter>max_iter) stop = true; end 
       
    iter = iter+1
  end

AIFlambda = lambda_best;
AIFlambda=real(AIFlambda)' % get the real part of IFlambda just in case
AIFmu_mu = AIFlambda(1); AIFsigma2_mu = AIFlambda(2); AIFalpha_sigma2 = AIFlambda(3); AIFbeta_sigma2 = AIFlambda(4);

%Keep track the paramters from Natural garident descent
mu_mu = NGlambda(1); sigma2_mu = NGlambda(2); alpha_sigma2 = NGlambda(3); beta_sigma2 = NGlambda(4);



%%%%%%%%%%%%%%%%%% Plot %%%%%%%%%%%%%%%%%
fontsize = 20;
x = 7:.001:13;
yy_FFVB = normpdf(x,mu_mu,sqrt(sigma2_mu));
yy_IFVB = normpdf(x,IFmu_mu,sqrt(IFsigma2_mu));
yy_AIFVB = normpdf(x,AIFmu_mu,sqrt(AIFsigma2_mu));
yy_MCMC = ksdensity(mu_mcmc,x);

% plot for mu
subplot(1,3,1)
plot(x,yy_MCMC,'--g',x,yy_FFVB,'-r',x,yy_IFVB,'-.b',x,yy_AIFVB,'-.c','LineWidth',2);
xlabel('\mu','FontSize', fontsize)
lgd = legend('MCMC','NGVB','IFVB','AIFVB');
lgd.FontSize = 15;

%plot for sigma
x = 0:.001:10;
inverse_gamma_pdf = @(x) exp(alpha_sigma2*log(beta_sigma2)-gammaln(alpha_sigma2)-(alpha_sigma2+1)*log(x)-beta_sigma2./x);
IFinverse_gamma_pdf = @(x) exp(IFalpha_sigma2*log(IFbeta_sigma2)-gammaln(IFalpha_sigma2)-(IFalpha_sigma2+1)*log(x)-IFbeta_sigma2./x);
AIFinverse_gamma_pdf = @(x) exp(AIFalpha_sigma2*log(AIFbeta_sigma2)-gammaln(AIFalpha_sigma2)-(AIFalpha_sigma2+1)*log(x)-AIFbeta_sigma2./x);
yy_AIFVB = AIFinverse_gamma_pdf(x);
yy_FFVB = inverse_gamma_pdf(x);
yy_IFVB = IFinverse_gamma_pdf(x);
yy_MCMC = ksdensity(sigma2_mcmc,x);

subplot(1,3,2)
plot(x,yy_MCMC,'--g',x,yy_FFVB,'-r',x,yy_IFVB,"-.b",x,yy_AIFVB,"-.c",'LineWidth',2);
lgd = legend('MCMC','NGVB','IFVB','AIFVB');
lgd.FontSize = 15;
xlabel('\sigma^2','FontSize', fontsize)

%Plot the ELBO
subplot(1,3,3)
plot(LB_bar,'-r','LineWidth',2)
hold on
plot(IFLB_bar,'-.b','LineWidth',1)
hold on
plot(AIFLB_bar,'-.c','LineWidth',1)
hold off
lgd = legend('NGVB','IFVB','AIFVB');
lgd.FontSize = 15;
xlabel('ELBO','FontSize', fontsize)


