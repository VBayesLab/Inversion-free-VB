function B = polar_retraction(X)
[m,p] = size(X);
[U,~,V] = svd(X);
B = U(:,1:p)*(V');

end
