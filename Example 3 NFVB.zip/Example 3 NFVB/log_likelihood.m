function f = log_likelihood(y,X,W_seq,beta)

nnet_output = neural_net_output(X,W_seq,beta);
%f = sum(y.*nnet_output-log(1+exp(nnet_output)));

aa = log(1+exp(nnet_output));
Inf_index = aa == Inf;
f1 = sum(y(Inf_index).*nnet_output(Inf_index)-nnet_output(Inf_index)-log(1+exp(-nnet_output(Inf_index))));
f2 = sum(y(~Inf_index).*nnet_output(~Inf_index)-log(1+exp(nnet_output(~Inf_index))));
f = f1+f2;



end



