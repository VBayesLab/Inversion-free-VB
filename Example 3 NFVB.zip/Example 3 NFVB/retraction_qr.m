function Y = retraction_qr(X, U, t)
 if nargin < 3
     Y = X + U;
 else
     Y = X + t*U;
 end
[Q, R] = qr(Y, 0);
    % The instruction with R ensures we are not flipping signs
    % of some columns, which should never happen in modern Matlab
    % versions but may be an issue with older versions.
Y = Q * diag(sign(sign(diag(R))+.5));
end