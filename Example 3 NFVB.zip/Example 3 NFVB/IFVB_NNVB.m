% Inverse-free natural gradient normalizing flow VB

clear all
data = load('germancredit_data.txt');
y = data(:,end);
y(y==2)=0;
data(:,end) = y;
data_test = data(801:end,:);
n = 800; 
data = data(1:n,:);
y_train = data(:,end);
X_train = data(:,1:end-1);
mean_X = mean(X_train); mean_X(16:end) = 0;
std_X = std(X_train); std_X(16:end) = 1;
X_train = [zscore(X_train(:,1:15)),X_train(:,16:end)];
X_train = [ones(n,1),X_train];
y_test = data_test(:,end);
n_test = length(y_test);
X_test = data_test(:,1:end-1);
X_test = X_test-(ones(n_test,1)*mean_X);
X_test = X_test./(ones(n_test,1)*std_X);
X_test = [ones(n_test,1),X_test];

X_train = X_train(:,1:10);
X_test = X_test(:,1:10);
%================= end data processing =============================%

rng(10000)

batchsize = 100;
n_units = [5];
eps0 = .01;
patience_parameter = 50;
smooth_window = 50;
max_iter = 10000;
norm_gradient_threshold = 10;
outer_product = [];
iter = 1;

data = [y_train,X_train];
datasize = length(y_train);

L = length(n_units); % the number of hidden layers
p = size(X_train,2)-1; % number of covariates
index_track = zeros(1,L); % keep track of indices of Wj matrices: index_track(1) is the total elements in W1, index_track(2) is the total elements in W1 & W2,...
index_track(1) = n_units(1)*(p+1); % size of W1 is m1 x (p+1) with m1 number of units in the 1st hidden layer 
for j = 2:L
    index_track(j) = index_track(j-1)+n_units(j)*(n_units(j-1)+1);
end
d_w = index_track(L); % the total number of weights up to (and including) the last layer
d_beta = n_units(L)+1; % dimension of the weights beta connecting the last layer to the output
d_theta = d_w+d_beta; % the total number of parameters
%--------------------------------------
% initialise lambda  
W1 = eye(d_theta); W2 = eye(d_theta); b1 = zeros(d_theta,1); b2 = zeros(d_theta,1);
d_lambda = 2*(d_theta^2+d_theta);
%----------------------------------------
act_type = 'Sigmoid'; % activation function for VB network

S = 100; % the number of Monte Carlo samples to estimate the gradient
tau = max_iter/2; % threshold tau before reducing constant learning rate eps0
momentum_weight = 0.6; %weight in the momentum 
gamma_ridge = 0.1; % shrinkage parameter, put a l2 regularization on all weights of the deep learning network

tic 

minibatch = datasample(data,batchsize);
y = minibatch(:,1);
X = minibatch(:,2:end);

rqmc = normrnd(0,1,S,d_theta);      
lb = zeros(S,1);
    parfor s=1:S
        epsilon = rqmc(s,:)';
        z = activation(W1*epsilon+b1,act_type);
        theta = W2*z+b2;
                               
        Wnn1 = reshape(theta(1:index_track(1)),n_units(1),p+1);
        Wnn_seq = cell(1,L); % cells to store weight matrices
        Wnn_seq{1} = Wnn1; 
        for j = 2:L
            index = index_track(j-1)+1:index_track(j);
            Wnnj = reshape(theta(index),n_units(j),n_units(j-1)+1); % size of Wj is l_j x (l_{j-1}+1)
            Wnn_seq{j} = Wnnj; 
        end
        beta = theta(d_w+1:d_theta);

        grad_prior = -gamma_ridge*theta;           
        grad_llh = gradient_log_likelihood(Wnn_seq,beta,X,y,datasize);
        grad_ell = grad_prior + grad_llh;
        
        act_derivative = activation_derivative(W1*epsilon+b1,act_type); % h'( h^{-1}(z) )
        aux_matrix = W2*diag(act_derivative);
        
        grad_theta_W1 = kron(epsilon,aux_matrix'*grad_ell);
        grad_theta_b1 = aux_matrix'*grad_ell;
        grad_theta_W2 = kron(z,grad_ell);
        grad_theta_b2 = grad_ell;
        
        grad_z = activation_2derivative(W1*epsilon+b1,act_type); % h''( h^{-1}(z) )      
        grad_z_W1 = kron(epsilon,act_derivative.*grad_z);
        grad_z_b1 = grad_z;
        grad_z_W2b2 = zeros(d_theta*(d_theta+1),1);
        
        grad_lambda(:,s) = [grad_theta_W1;grad_theta_b1;grad_theta_W2;grad_theta_b2]+...
            [grad_z_W1;grad_z_b1;grad_z_W2b2];

        llh = log_likelihood(y_train,X_train,Wnn_seq,beta);    
        lb(s) = d_theta/2*log(gamma_ridge)-1/2*gamma_ridge*((theta')*theta)+llh+1/2*(epsilon')*epsilon+sum(log(act_derivative));    
    end
grad_lb = mean(grad_lambda,2); % Euclidean gradient of LB

% update outer product
epsilon = normrnd(0,1,1,d_theta)';      
z = activation(W1*epsilon+b1,act_type);
theta = W2*z+b2;
act_derivative = activation_derivative(W1*epsilon+b1,act_type); % h'( h^{-1}(z) )
grad_z = activation_2derivative(W1*epsilon+b1,act_type); % h''( h^{-1}(z) )      
delta_z = -(1./act_derivative).*(W1*epsilon)-grad_z;       
grad_log_q_W1 = -(epsilon*epsilon')*W1; grad_log_q_W1 = grad_log_q_W1(:);
grad_log_q_b1 = W1*epsilon;
grad_log_q_W2 = (theta-b2)*delta_z'; grad_log_q_W2 = grad_log_q_W2(:);
grad_log_q_b2 = -W2*delta_z;
grad_log_q_lambda = [grad_log_q_W1;grad_log_q_b1;grad_log_q_W2;grad_log_q_b2];

outer_product_new = grad_log_q_lambda;
NatGradient = grad_lb;
scale = grad_log_q_lambda'*grad_log_q_lambda;
for k = 1:size(outer_product,2)
    NatGradient = NatGradient - (outer_product(:,k)'*grad_lb)*outer_product(:,k);
    outer_product_new = outer_product_new - (outer_product(:,k)'*grad_log_q_lambda)*outer_product(:,k);
    scale = scale - (outer_product(:,k)'*grad_log_q_lambda)^2;
end
outer_product_new = 1/sqrt(1+scale)*outer_product_new;
outer_product =[outer_product,outer_product_new];
NatGradLB = iter*NatGradient; % natural grad of LB  
    grad_norm = norm(NatGradLB);
    if norm(NatGradLB)>norm_gradient_threshold
        NatGradLB = (norm_gradient_threshold/grad_norm)*NatGradLB;
    end

NatGradLB_W1 = reshape(NatGradLB(1:d_theta^2),d_theta,d_theta);
NatGradLB_b1 = NatGradLB(d_theta^2+1:d_theta*(d_theta+1));
NatGradLB_W2 = reshape(NatGradLB(d_theta*(d_theta+1)+1:d_theta*(2*d_theta+1)),d_theta,d_theta);
NatGradLB_b2 = NatGradLB(d_theta*(2*d_theta+1)+1:end);
% initialise the momentum grads
NatGradLB_W1_momentum = NatGradLB_W1; % initialise momentum gradient for W1
NatGradLB_b1_momentum = NatGradLB_b1; % initialise momentum gradient for b1
NatGradLB_W2_momentum = NatGradLB_W2; % initialise momentum gradient for W2
NatGradLB_b2_momentum = NatGradLB_b2; % initialise momentum gradient for b2

iter = 0; stop = false; LB = 0; patience = 0; LB_smooth = 0;
while ~stop
    iter = iter+1
    if iter>tau
        stepsize=eps0*tau/iter;
    else
        stepsize=eps0;
    end
    proj_grad_W1 = projection_stiefel(W1,NatGradLB_W1_momentum);
    [W1,~] = cholesky_qr(W1+stepsize*proj_grad_W1);
    
    b1 = b1+stepsize*NatGradLB_b1_momentum;    
    proj_grad_W2 = projection_stiefel(W2,NatGradLB_W2_momentum);
    [W2,~] = cholesky_qr(W2+stepsize*proj_grad_W2);
    b2 = b2+stepsize*NatGradLB_b2_momentum;    
    
    minibatch = datasample(data,batchsize);
    y = minibatch(:,1);
    X = minibatch(:,2:end);

    rqmc = normrnd(0,1,S,d_theta);            
    parfor s=1:S
        epsilon = rqmc(s,:)';
        z = activation(W1*epsilon+b1,act_type);
        theta = W2*z+b2;
                               
        Wnn1 = reshape(theta(1:index_track(1)),n_units(1),p+1);
        Wnn_seq = cell(1,L); % cells to store weight matrices
        Wnn_seq{1} = Wnn1; 
        for j = 2:L
            index = index_track(j-1)+1:index_track(j);
            Wnnj = reshape(theta(index),n_units(j),n_units(j-1)+1); % size of Wj is l_j x (l_{j-1}+1)
            Wnn_seq{j} = Wnnj; 
        end
        beta = theta(d_w+1:d_theta);

        grad_prior = -gamma_ridge*theta;           
        grad_llh = gradient_log_likelihood(Wnn_seq,beta,X,y,datasize);
        grad_ell = grad_prior + grad_llh;
        
        act_derivative = activation_derivative(W1*epsilon+b1,act_type); % h'( h^{-1}(z) )
        aux_matrix = W2*diag(act_derivative);
        
        grad_theta_W1 = kron(epsilon,aux_matrix'*grad_ell);
        grad_theta_b1 = aux_matrix'*grad_ell;
        grad_theta_W2 = kron(z,grad_ell);
        grad_theta_b2 = grad_ell;
        
        grad_z = activation_2derivative(W1*epsilon+b1,act_type); % h''( h^{-1}(z) )      
        grad_z_W1 = kron(epsilon,act_derivative.*grad_z);
        grad_z_b1 = grad_z;
        grad_z_W2b2 = zeros(d_theta*(d_theta+1),1);
        
        grad_lambda(:,s) = [grad_theta_W1;grad_theta_b1;grad_theta_W2;grad_theta_b2]+...
            [grad_z_W1;grad_z_b1;grad_z_W2b2];

        llh = log_likelihood(y_train,X_train,Wnn_seq,beta);    
        lb(s) = d_theta/2*log(gamma_ridge)-1/2*gamma_ridge*((theta')*theta)+llh+1/2*(epsilon')*epsilon+sum(log(act_derivative));            
    end
    grad_lb = mean(grad_lambda,2);    
    % now compute natural grad and update outer products
    epsilon = normrnd(0,1,1,d_theta)';      
    z = activation(W1*epsilon+b1,act_type);
    theta = W2*z+b2;
    act_derivative = activation_derivative(W1*epsilon+b1,act_type); % h'( h^{-1}(z) )
    grad_z = activation_2derivative(W1*epsilon+b1,act_type); % h''( h^{-1}(z) )      
    delta_z = -(1./act_derivative).*(W1*epsilon)-grad_z;       
    grad_log_q_W1 = -(epsilon*epsilon')*W1; grad_log_q_W1 = grad_log_q_W1(:);
    grad_log_q_b1 = W1*epsilon;
    grad_log_q_W2 = (theta-b2)*delta_z'; grad_log_q_W2 = grad_log_q_W2(:);
    grad_log_q_b2 = -W2*delta_z;
    grad_log_q_lambda = [grad_log_q_W1;grad_log_q_b1;grad_log_q_W2;grad_log_q_b2];
    
    outer_product_new = grad_log_q_lambda;
    NatGradient = grad_lb;
    scale = grad_log_q_lambda'*grad_log_q_lambda;
    for k = 1:size(outer_product,2)
        NatGradient = NatGradient - (outer_product(:,k)'*grad_lb)*outer_product(:,k);
        outer_product_new = outer_product_new - (outer_product(:,k)'*grad_log_q_lambda)*outer_product(:,k);
        scale = scale - (outer_product(:,k)'*grad_log_q_lambda)^2;
    end
    outer_product_new = 1/sqrt(1+scale)*outer_product_new;
    outer_product =[outer_product,outer_product_new];
    if size(outer_product,2)>100
        outer_product = outer_product(:,end-99:end);
    end

    NatGradLB = iter*NatGradient; % natural grad of LB  
        grad_norm = norm(NatGradLB);
        if norm(NatGradLB)>norm_gradient_threshold
            NatGradLB = (norm_gradient_threshold/grad_norm)*NatGradLB;
        end


    NatGradLB_W1 = reshape(NatGradLB(1:d_theta^2),d_theta,d_theta);
    NatGradLB_b1 = NatGradLB(d_theta^2+1:d_theta*(d_theta+1));
    NatGradLB_W2 = reshape(NatGradLB(d_theta*(d_theta+1)+1:d_theta*(2*d_theta+1)),d_theta,d_theta);
    NatGradLB_b2 = NatGradLB(d_theta*(2*d_theta+1)+1:end);
 
    zeta = projection_stiefel(W1,NatGradLB_W1_momentum); % vector transport to move gradLB_W1_momentum, which is a projection in Stiefel manifold     
    NatGradLB_W1_momentum = momentum_weight*zeta+(1-momentum_weight)*NatGradLB_W1; % update momentum grad for W1
    NatGradLB_b1_momentum = momentum_weight*NatGradLB_b1_momentum+(1-momentum_weight)*NatGradLB_b1; % update momentum grad for b1    
    zeta = projection_stiefel(W2,NatGradLB_W2_momentum); % vector transport to move gradLB_W2_momentum, which is a projection in Stiefel manifold     
    NatGradLB_W2_momentum = momentum_weight*zeta+(1-momentum_weight)*NatGradLB_W2; % update momentum grad for W2
    NatGradLB_b2_momentum = momentum_weight*NatGradLB_b2_momentum+(1-momentum_weight)*NatGradLB_b2; % update momentum grad for b2
    
    LB(iter) = mean(lb);
        
    if iter>smooth_window
        LB_smooth(iter-smooth_window) = mean(LB(iter-smooth_window:iter));    
        if LB_smooth(iter-smooth_window)>=max(LB_smooth)
            W1_best = W1; W2_best = W2; b1_best = b1; b2_best = b2;
            patience = 0;
        else
            patience = patience+1;
        end
        LB_current = LB_smooth(end)
    end
    
    if (patience>patience_parameter)||(iter>max_iter) stop = true; end 
end 
LB_smooth_IFVB = LB_smooth;
CPU_IFVB = toc;

figure
plot(LB_smooth_IFVB)
save('results_IFVB')


