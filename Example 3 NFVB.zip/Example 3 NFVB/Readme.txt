Implementing the Inverse-free Natural Gradient VB method for the case the variational distribution is based on a normnalizing flow. Orthogonality constraint is imposed on the weight matrices.
See Example 3 in "Natural Gradient Variational Bayes without Fisher Matrix Analytic Calculation and Its Inversion" by GODICHON-BAGGIONI, D. NGUYEN, AND M-N. TRAN.

OrdinaryGrad_NNVB.m implements manifold VB using the Euclidean gradient of the lower bound 
IFVB_NNVB implements manifold VB using the natural gradient of the lower bound 

File for_plot.m produces a figure to compare the lower bounds.

