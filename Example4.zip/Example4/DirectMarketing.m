clear all
load('DirectMarketing.mat')

rng(10000)

X_train = X;
y_train = y;

batchsize = 100;
n_units = [10];
eps0 = .01;

tic
[W_seq,beta,mean_sigma2,~,MSE_IFVB_val_best,MSE_IFVB] = DL_training_IFVB(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_IFVB_test,MSE_IFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_IFVB = toc;
save('results_DirectMarketing_IFVB.mat')

tic
[W_seq,beta,mean_sigma2,~,MSE_AIFVB_val_best,MSE_AIFVB] = DL_training_AIFVB(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0);
[PPS_AIFVB_test,MSE_AIFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_AIFVB = toc;
save('results_DirectMarketing_AIFVB.mat')

isotropic = false;
tic
[W_seq,beta,mean_sigma2,shrinkage_gamma_seq,MSE_NAGVAG_val_best,MSE_NAGVAG] = DL_training(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0,isotropic);
[PPS_NAGVAG_test,MSE_NAGVAG_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU_NAGVAG = toc;
save('results_DirectMarketing_VB.mat')

load('results_DirectMarketing_VB.mat')
load('results_DirectMarketing_IFVB.mat')
load('results_DirectMarketing_AIFVB.mat')

plot(MSE_NAGVAG,'-b','LineWidth',1.5)
hold on
plot(MSE_IFVB,'--','LineWidth',1.5)
plot(MSE_AIFVB,'-.','LineWidth',1.5)
hold off 
legend('NAGVAG','IFVB','AIFVB')
xlabel('Iteration','FontSize',14)
ylabel('MSE','FontSize',14)
