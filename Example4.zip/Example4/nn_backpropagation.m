function gradient = nn_backpropagation(X,Y_train,W_seq,beta)
% compute the gradient in a neural net using backpropagation
n_train = size(X,1);
L = length(W_seq);
a_seq = cell(1,L);
Z_seq = cell(1,L);

a_seq{1} = W_seq{1}*X';
Z_seq{1} = [ones(1,n_train);activation(a_seq{1},'ReLU')];
for j=2:L
    a_seq{j} = W_seq{j}*Z_seq{j-1};
    Z_seq{j} = [ones(1,n_train);activation(a_seq{j},'ReLU')];
end

delta_seq = cell(1,L+1);
Y = beta'*Z_seq{L};
delta_seq{L+1} = (Y_train - Y')';

delta_seq{L} = (beta(2:end)*delta_seq{L+1}).*activation_derivative(a_seq{L},'ReLU');
for j=L-1:-1:1
    Wj_tilde = W_seq{j+1};
    Wj_tilde = Wj_tilde(:,2:end);
    delta_seq{j} = (activation_derivative(a_seq{j},'ReLU')).*(Wj_tilde'*delta_seq{j+1});
end
gradient_W1 = delta_seq{1}*X;
gradient = gradient_W1(:);
for j = 2:L
    gradient_Wj = delta_seq{j}*(Z_seq{j-1})';
    gradient = [gradient;gradient_Wj(:)];
end
gradient = [gradient;Z_seq{L}*delta_seq{L+1}'];

%%
% Y_train: reference output in training set
% values: stored activation values of all units during feed forward
% w: weights in network
% text: Activation function type
% w_grad: gradient of all weights in network
% values{1} = values{1}(2:end,:);
% 
% n_train = length(Y_train);
% num_layer = length(values)-1; % number of layers in network
% Y_predict = values{end}';
% w = [W_seq,beta'];
% 
% % Step 1: Calculate initial error on output layer
% delta = (Y_predict - Y_train)';
% 
% % Step 2: Backpropagate through network -> iteration over the weight layers from
% % right to left
% w_grad_vec = [];
% for i = num_layer:-1:1
%     % Calculate gradient of unit_w{i}
%     w_unit_grad{i} = values{i}*delta';%
%     w_bias_grad{i} = sum(delta,2);
%     
%     % Combine unit_w_grad and bias_w_grad
%     w_grad{i} = [w_bias_grad{i}';w_unit_grad{i}];
%     w_grad_vec = [w_grad_vec; w_grad{i}(:)];
%     % Next, calculate error at previous layer
%     if (i>1)
%         temp = [ones(1,n_train);values{i-1}]; % add a bias to each layer
%         Z = w{i-1} * temp;
%         w_unit{i} = w{i}(:,2:end);
%         delta = (w_unit{i}'*delta).*activation_grad(Z, 'ReLU');
%     end
% end
% w_grad_vec = flipud(w_grad_vec);
% gradient = w_grad_vec;
end
