function PPS = validation_PPS(y_val,X_val,W_seq,beta,A_sig2,B_sig2)
% compute the prediction loss (minus log-likelihood) and MSE for normal-NN model

n_val = length(y_val);
nnet_output = neural_net_output(X_val,W_seq,beta);
MSE = sum((y_val-nnet_output).^2)/n_val;
mean_sig2inv = A_sig2/B_sig2;
PPS = 1/2*(log(B_sig2)-psi(A_sig2))+1/2*mean_sig2inv*MSE;

end



