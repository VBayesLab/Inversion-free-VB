function [PPS,MSE] = prediction_loss(ytest,Xtest,W_seq,beta,sigma2)
% compute the prediction loss (minus log-likelihood) and MSE for normal-NN model

ntest = length(ytest);
nnet_output = neural_net_output(Xtest,W_seq,beta);
MSE = sum((ytest-nnet_output).^2)/ntest;
%PPS = ntest*1/2*log(sigma2) + 1/2/sigma2*sum((ytest-nnet_output).^2);
%PPS = PPS/ntest;
PPS = 1/2*log(sigma2) + 1/2/sigma2*MSE;

end



