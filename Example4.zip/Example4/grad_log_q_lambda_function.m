function grad_log_q = grad_log_q_lambda_function(b,c,theta,mu)
% calculate the gradient of log_q w.r.t. lambda = (mu,b,c)

x = theta-mu;
kappa = 1/(1+sum(b.^2./c.^2));
gamma = sum(x.*b./c.^2);

d = b./c.^2;
grad_mu = x./c.^2-kappa*(d'*x)*d;

grad_b = -kappa*d - kappa^2*gamma^2*d + kappa*gamma*x./c.^2;

grad_c = -1./c + kappa*(b.^2)./(c.^3) + x.^2./c.^3 + kappa^2*gamma^2*b.^2./c.^3 - 2*kappa*gamma*x.*b./c.^3;

grad_log_q = [grad_mu;grad_b;grad_c];


% x = theta-mu;
% d = b./c;
% kappa = 1/(1+d'*d);
% 
% aux = sum((b.*x)./(c.^2));
% grad_mu = (x-kappa*aux*b)./(c.^2);
% 
% grad_b = -kappa*b./(c.^2) + (x.^2).*(kappa*b./(c.^2)-kappa^2*(b.^3)./(c.^4));
% 
% grad_c = -1./c+kappa*(b.^2)./(c.^3) + (x.^2).*(1./(c.^3)+kappa^2*(b.^4)./(c.^5)-kappa*(b.^2)./(c.^3));
% 
% grad_log_q = [grad_mu;grad_b;grad_c];
end
    
    



