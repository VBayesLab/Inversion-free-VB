function [Q,R] = cholesky_qr(A)
R = chol(A'*A,'upper');
Q = A/R;

end

