function f = activation_2derivative(z,type)
    % tanh
    if strcmp(type,'Tanh')
        f = 1-2*activation(z,'Tanh').*activation_derivative(z,'Tanh');
    end
    if strcmp(type,'Sigmoid')
        f = 1./(1+exp(-z)); 
        f1 = f.*(1-f);
        f = f1-2*f.*f1;
    end
    if strcmp(type,'Sigmoid1')
        a = 5;
        f = 1./(1+exp(-a*z)); 
        f1 = a*f.*(1-f);
        f = a*(f1-2*f.*f1);
    end
    if strcmp(type,'Linear')
        f = zeros(size(z));
    end


%     % rectified
%     if strcmp(type,'ReLU')
%         f = ones(size(z)); 
%         f(z<=0) = 0;
%     end
end