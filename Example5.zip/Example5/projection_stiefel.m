function proj = projection_stiefel(W,zeta)
% project zeta to the tangent space at W of the Stiefel manifold  
proj = zeta-W*(W')*zeta+W*mskew((W')*zeta);

end

