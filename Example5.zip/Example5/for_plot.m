clear all
load('results_OrdinaryGrad.mat')
load('results_IFVB.mat')

plot(LB_smooth_OrdinaryGrad,'--b','LineWidth',1.5)
hold on
plot(LB_smooth_IFVB,'-r','LineWidth',1.5)
hold off 
legend('VB','IFVB')
xlabel('Iteration','FontSize',14)
ylabel('Lower bound','FontSize',14)
