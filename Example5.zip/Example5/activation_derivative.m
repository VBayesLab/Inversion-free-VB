function f = activation_derivative(z,type)
    % tanh
    if strcmp(type,'Tanh')
        f = exp(-2*z); 
        f = (1-f)./(1+f); 
        f = 1-f.^2;
    end
    % rectified
    if strcmp(type,'ReLU')
        f = ones(size(z)); 
        f(z<=0) = 0;
    end
    if strcmp(type,'Sigmoid')
        f = 1./(1+exp(-z)); 
        f = f.*(1-f);
    end
    if strcmp(type,'Sigmoid1')
        a = 5; 
        f = 1./(1+exp(-a*z)); 
        f = a*f.*(1-f);
    end
    if strcmp(type,'Linear')
        a = 2; 
        f = a*ones(size(z));       
    end

end