function f = mskew(A)
f = 1/2*(A-A');

end